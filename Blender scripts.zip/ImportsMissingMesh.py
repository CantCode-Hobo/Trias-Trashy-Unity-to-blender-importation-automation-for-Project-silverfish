import os
import json
import copy
import bpy
import math

# FUNNY BUG [1] : "RuntimeError: Error: Object 'NPC_State_Infantry_Marksman.json.002' already in collection 'ImportTandem'"

# For some reason the code will somtimes import a mesh check for said mesh, then get bugged out. This has to do with the collection its in, the bug should be fixed.

# FUNNY FIX [1] : If you encounter this bug even after I "fixed" it. Delete the custom scene were the meshes get imported. You can move everything out of the collection and back in after if you want.

# Path to the text file where the missing meshes are referenced.
txt_file_path = r"D:\Users\Admin\Downloads\Character_Default\Code\wip\Tandem\Tandem.txt"

# Base paths for assets and json files. Ensure paths are formatted correctly, e.g ending with "Exports/Game/Assets" and "Exports/SilverFish/Content".
base_path_Pskx = r"D:/Users/Admin/Downloads/Character_Default/FModel/Output/Exports/Game/Assets"
base_path_Json = r"D:/Users/Admin/Downloads/Character_Default/FModel/Output/Exports/SilverFish/Content"

# Predefined lists for code processing and lookup.
List_Pskx = ["StaticMeshComponent", "StaticMesh", "Prop_WoodPallet_C"]
List_Json = ["InheritableComponentHandler", "ChildActorComponent"]
List_Properties_Names = ["ComponentKey", "OwnerClass", "ChildActorClass", "StaticMesh", "BodySetup", "Meshes", "RelativeLocation", "RelativeRotation", "RelativeScale3D"]
List_Ignored = ["Pontoon_BP.json", "PhysicsProp_Master_BP.json", "NPC_Master_BP.json", "AmbSFX_Forest_BP.json", "AI_Spawner_Squad_BP.json", "AmbSFX_Town_BP.json", "Waypoint_BP.json", "SavePoint_BP.json", "Artifact_Spawner_BP.json", "AnomalyField_BP.json"]

# Define the collection name were the imported and created meshes will go. 
# Define the collection name at the top for easy editing
Collection_name = "ImportTandem"

# List_Pskx indicates the "type" code block will link to pskx files which is what is imported.
# List_Json indicates the "type" code block will link to json files can be searched for more files.
# List_Properties_Names tells what info inside the "type" blocks is to be used.
# List_Ignored lists the files to be ignored, included for convenience. These files do not lead to PSKX files and are used for Unity information gathering.

#(Set to "T" or "F") T = True F = False

# Flag for showing unknown types 
Show_Unknown_Type = "F"
# Flag for showing properties in the log
Show_Properties = "F"
# Flag for showing ignored files
Show_Ignored = "F"
# Flag for importing valid pskx files
Import_PSKX_With_Blender = "T"
# Flag for removeal of created parent cubes while keeping child meshes transforms.
Remove_cube_parent = "F"
# New flag for auto-selecting the Scene Collection
Collection_Auto_Select = "T"

# Reads the tandem.txt file to extract missing mesh data and their locational information.
def read_tandem_txt(file_path):
    missing_meshes = []
    locational_data_list = []  # List to hold locational data for each missing mesh

    try:
        with open(file_path, 'r') as file:
            lines = file.readlines()
        
        # Loop through each line in the file
        for line in lines:
            if line.startswith("Missing"):
                try:
                    parts = line.split(" at ")
                    if len(parts) > 1:
                        # Extract the name of the missing mesh
                        mesh_name = parts[0].split(":")[1].strip()

                        # Check if the mesh name is in the List_Ignored
                        if mesh_name in List_Ignored:
                            print(f"Skipping ignored mesh: {mesh_name}")
                            continue

                        location_info = parts[1].split(" rotation ")[0].strip()
                        rotation_info = parts[1].split(" rotation ")[1].split(" scale ")[0].strip()
                        scale_info = parts[1].split(" scale ")[1].split(" path ")[0].strip()
                        path_info = parts[1].split(" path = ")[1].strip().split(" ")[0]

                        # Extract locational data
                        locational_data = {
                            "Location": {
                                "X": float(location_info.split(",")[0]),
                                "Y": float(location_info.split(",")[1]),
                                "Z": float(location_info.split(",")[2])
                            },
                            "Rotation": {
                                "Roll": float(rotation_info.split(",")[0]),
                                "Pitch": float(rotation_info.split(",")[1]),
                                "Yaw": float(rotation_info.split(",")[2])
                            },
                            "Scale": {
                                "X": float(scale_info.split(",")[0]),
                                "Y": float(scale_info.split(",")[1]),
                                "Z": float(scale_info.split(",")[2])
                            }
                        }

                        missing_meshes.append({
                            "locational_data": locational_data,
                            "path": path_info,
                            "name": mesh_name
                        })

                        # Append locational data to the list
                        locational_data_list.append(locational_data)

                        # Log the locational data
                        print(f"Missing: Path: {path_info}, Location: {location_info}, Rotation: {rotation_info}, Scale: {scale_info}")

                except Exception as e:
                    print(f"Error parsing line: {line}")
                    print(f"Error details: {e}")
    except FileNotFoundError:
        print(f"Error: The file at {file_path} was not found.")
        return None
    except Exception as e:
        print(f"Error reading the file: {e}")
        return None

    return missing_meshes, locational_data_list

# Will ensure the collection exists, if it does, it removes the old one and moves its contents into the new one. This is to fix FUNNY BUG [1]
def ensure_collection_exists(collection_name):
    """Ensure that a collection with the given name exists in Blender."""
    if Import_PSKX_With_Blender == "T":
        if collection_name in bpy.data.collections:
            # Create a new collection with ".1" suffix
            new_collection_name = f"{collection_name}.1"
            new_collection = bpy.data.collections.new(new_collection_name)
            bpy.context.scene.collection.children.link(new_collection)

            # Move all objects from the existing collection to the new one
            old_collection = bpy.data.collections[collection_name]
            for obj in old_collection.objects:
                new_collection.objects.link(obj)
                old_collection.objects.unlink(obj)

            # Remove the old collection
            bpy.data.collections.remove(old_collection)

            # Rename the new collection to the original name
            new_collection.name = collection_name

            return new_collection
        else:
            # Create a new collection if it doesn't exist
            new_collection = bpy.data.collections.new(collection_name)
            bpy.context.scene.collection.children.link(new_collection)
            return new_collection
    return None


# Ensure the collection exists
import_collection = ensure_collection_exists(Collection_name)

# Creates a cube in Blender with specified locational data and assigns a unique name, helps the placement of imported files. (Also helps with collection creation)
def create_cube(name, locational_data, name_count):
    """Create a cube in Blender with specified locational data and a unique name."""
    if Import_PSKX_With_Blender == "T":
        bpy.ops.mesh.primitive_cube_add(size=1)
        cube = bpy.context.active_object

        # Determine the unique name for the cube
        if name_count[name] > 0:
            cube.name = f"{name}.{name_count[name]:03d}"
        else:
            cube.name = name

        # Increment the count for this name
        name_count[name] += 1

        cube.location.x = locational_data['Location']['X']
        cube.location.y = locational_data['Location']['Y']
        cube.location.z = locational_data['Location']['Z']

        cube.rotation_euler.x = math.radians(locational_data['Rotation']['Roll'])
        cube.rotation_euler.y = math.radians(locational_data['Rotation']['Pitch'])
        cube.rotation_euler.z = math.radians(locational_data['Rotation']['Yaw'])

        cube.scale.x = locational_data['Scale']['X']
        cube.scale.y = locational_data['Scale']['Y']
        cube.scale.z = locational_data['Scale']['Z']

        # Link the cube to the "ImportTandem" collection
        import_collection.objects.link(cube)
        bpy.context.scene.collection.objects.unlink(cube)

        return cube
    return None

# Processes transformation data (location, rotation, scale) and adjusts values as needed.
def process_transform(data, transform_type):
    if transform_type == 'location':
        x = data['X'] / 100
        y = data['Y'] / 100
        z = data['Z'] / 100
        y_flipped = -y if y > 0 else abs(y)
        return {"X": round(x, 5), "Y": round(y_flipped, 5), "Z": round(z, 5)}

    elif transform_type == 'rotation':
        yaw = -data['Yaw'] if data['Yaw'] >= 0 else abs(data['Yaw'])
        pitch = -data['Pitch'] if data['Pitch'] >= 0 else abs(data['Pitch'])
        return {"Roll": round(data['Roll'], 5), "Pitch": round(pitch, 5), "Yaw": round(yaw, 5)}

    elif transform_type == 'scale':
        x = data.get('X', 1)
        y = data.get('Y', 1)
        z = data.get('Z', 1)
        return {"X": round(x, 5), "Y": round(y, 5), "Z": round(z, 5)}

# Function to check if file path is valid
def check_file_path(file_path):
    return os.path.exists(file_path)  # Return True if the path exists, False otherwise

# Processes JSON data to determine valid paths for PSKX and JSON files.
def process_json(missing_data, cubes):
    valid_pskx_paths = []
    valid_json_paths = []
    
    for index, data in enumerate(missing_data):
        file_path = data['path'].strip('"')  # Strip the extra quotes
        
        if file_path.endswith('.json'):
            valid_json_paths.append((file_path, cubes[index]))
        elif file_path.endswith('.pskx'):
            valid_pskx_paths.append((file_path, cubes[index]))
        else:
            print(f"Invalid file path (not a JSON or PSKX): {file_path}")

    return valid_pskx_paths, valid_json_paths

# Imports a PSKX file into Blender and applies locational data, associating it with a cube. (Also places the imported meshes into a collection)
def import_pskx_with_blender(file_path, locational_data, cube):
    """ Import a PSKX file into Blender with specified locational data and associate it with a cube. """
    try:
        # Import the PSKX file
        bpy.ops.import_scene.psk(filepath=file_path)

        # Get all imported objects
        imported_objects = bpy.context.selected_objects

        # Set location, rotation, and scale for each imported object
        for obj in imported_objects:
            obj.location.x = locational_data['Location']['X']
            obj.location.y = locational_data['Location']['Y']
            obj.location.z = locational_data['Location']['Z']

            obj.rotation_euler.x = math.radians(locational_data['Rotation']['Roll'])
            obj.rotation_euler.y = math.radians(locational_data['Rotation']['Pitch'])
            obj.rotation_euler.z = math.radians(locational_data['Rotation']['Yaw'])

            obj.scale.x = locational_data['Scale']['X']
            obj.scale.y = locational_data['Scale']['Y']
            obj.scale.z = locational_data['Scale']['Z']

            # Link each imported object to the "ImportTandem" collection
            import_collection.objects.link(obj)
            bpy.context.scene.collection.objects.unlink(obj)

            # Ensure children are linked to the same collection
            for child in obj.children:
                import_collection.objects.link(child)
                bpy.context.scene.collection.objects.unlink(child)

        # Parent the first imported object to the cube if needed
        if imported_objects:
            imported_objects[0].parent = cube

        print(f"Imported and transformed {file_path} successfully in Blender, associated with {cube.name}.")
    except Exception as e:
        print(f"Failed to import {file_path} in Blender: {str(e)}")

# Checks the validity of a file path and processes it based on its type and location data.
def process_and_check_file_path(file_path, extension, is_json, processed_file_paths, valid_paths_count, valid_pskx_count, invalid_paths_count, location_data=None, cube=None):
    if not isinstance(invalid_paths_count, int):
        print("Invalid type for invalid_paths_count, resetting to 0.")
        invalid_paths_count = 0

    # Skip the file if it's in the List_Ignored
    if file_path.split("\\")[-1] in List_Ignored:
        if Show_Ignored == "T":
            print(f"Skipping ignored file: {file_path}")
        return valid_paths_count, valid_pskx_count, invalid_paths_count

    # Increment the count for each instance of the same file path
    processed_file_paths[file_path] = processed_file_paths.get(file_path, 0) + 1

    # Now check if the file exists
    is_valid = check_file_path(file_path)
    log_message = f"File path: {file_path} - {'Path Valid' if is_valid else 'Path Not Valid'}"
    
    if is_valid:
        valid_paths_count += 1
        if file_path.endswith(".pskx"):  # Increment valid PSKX count
            valid_pskx_count += 1
            if Import_PSKX_With_Blender == "T":
                import_pskx_with_blender(file_path, location_data, cube)
    else:
        invalid_paths_count += 1  # Increment the invalid paths counter
        
    # Add locational data to the log message if available
    if location_data:
        log_message += (f", Location: {location_data['Location']['X']},{location_data['Location']['Y']},{location_data['Location']['Z']} "
                        f", Rotation: {location_data['Rotation']['Roll']},{location_data['Rotation']['Pitch']},{location_data['Rotation']['Yaw']} "
                        f", Scale: {location_data['Scale']['X']},{location_data['Scale']['Y']},{location_data['Scale']['Z']}")

    # Add cube association to the log message, defaulting to "None" if no cube is present. A instance of "None" indicates an error.
    cube_name = cube.name if cube else "None"
    log_message += f", Cube: {cube_name}"

    # Log only if Show_Ignored is not "T"
    if Show_Ignored == "F" or file_path.split("\\")[-1] not in List_Ignored:
        print(log_message)
    
    return valid_paths_count, valid_pskx_count, invalid_paths_count

# Reads a JSON file and processes its contents to extract paths and handle nested data.
def read_json_file(json_path, known_paths, processed_file_paths, valid_paths_count, valid_pskx_count, invalid_paths_count, parent_location=None, txt_location_data=None, cube=None):
    unknown_types = 0

    # Skip the file if it's in the List_Ignored and log that it was skipped if Show_Ignored is set to "T"
    if json_path.split("\\")[-1] in List_Ignored and Show_Ignored == "F":
        return [], [], unknown_types, valid_paths_count, valid_pskx_count, invalid_paths_count

    # Track how many times each file path has been processed
    processed_file_paths[json_path] = processed_file_paths.get(json_path, 0) + 1

    try:
        with open(json_path, 'r') as f:
            data = json.load(f)
    except FileNotFoundError:
        print(f"Error: The file at {json_path} was not found.")
        invalid_paths_count += 1
        return [], [], unknown_types, valid_paths_count, valid_pskx_count, invalid_paths_count
    except Exception as e:
        print(f"Error reading the file {json_path}: {e}")
        invalid_paths_count += 1
        return [], [], unknown_types, valid_paths_count, valid_pskx_count, invalid_paths_count

    pskx_paths = []
    json_paths = []

    for item in data:
        if "Type" in item:
            type_value = item["Type"]
            name_value = item.get("Name", "Unnamed")

            if name_value.split("\\")[-1] in List_Ignored and Show_Ignored == "F":
                continue  # Skip this item entirely

            if type_value in List_Pskx or type_value in List_Json:
                properties = item.get("Properties", {})
                nested_pskx_paths, nested_json_paths, unknown_types_nested, valid_paths_count, valid_pskx_count, invalid_paths_count = process_json_item(
                    item, type_value, properties, name_value, valid_paths_count, valid_pskx_count, invalid_paths_count, parent_location, processed_file_paths, known_paths, txt_location_data, cube
                )

                pskx_paths.extend(nested_pskx_paths)
                json_paths.extend(nested_json_paths)
                unknown_types += unknown_types_nested
            else:
                unknown_types += 1
                if Show_Unknown_Type == "T":
                    print(f"Unknown type found: {type_value} in file {json_path}")

    return pskx_paths, json_paths, unknown_types, valid_paths_count, valid_pskx_count, invalid_paths_count

# Processes individual items within a JSON file, handling properties and nested paths.
def process_json_item(item, type_value, properties, name_value, valid_paths_count, valid_pskx_count, invalid_paths_count, parent_location, processed_file_paths, known_paths, txt_location_data, cube):
    unknown_types = 0
    pskx_paths = []
    json_paths = []
    
    # Handle special check for BodySetup if type is StaticMesh
    if type_value == "StaticMesh" and "BodySetup" in item:
        properties["BodySetup"] = item["BodySetup"]

    # Prepare location data
    location_data = prepare_location_data(parent_location, properties, txt_location_data)

    # Process "Records" inside "Properties" (Records are special instances that have links to other files and names that should be ignored in these links)
    if "Records" in properties:
        for record in properties["Records"]:
            # Process "ComponentKey" only if present
            if "ComponentKey" in record:
                component_key = record["ComponentKey"]

                # Process "OwnerClass" for ObjectPath
                owner_class = component_key.get("OwnerClass", {})
                owner_class_path = owner_class.get("ObjectPath", "").strip('"')

                if owner_class_path:
                    # Create the full path
                    file_path = combine_paths(base_path_Json, owner_class_path, ".json", True)

                    # Check if the path is in the ignored list
                    if file_path.split("\\")[-1] in List_Ignored:
                        if Show_Ignored != "F":
                            print(f"Skipping ComponentKey due to ignored OwnerClass path: {file_path}")
                        continue

                    # Process "SCSVariableName" if available (SCSVariableName holds the name of temp ignored files, these should only be ignored in the context of the same properties as the SCSVariableName)
                    if "SCSVariableName" in component_key:
                        scs_variable_name = component_key["SCSVariableName"].strip('"')
                        if Show_Ignored != "F":
                            print(f"Found property: SCSVariableName: {scs_variable_name}")

                        # Add both .json and .pskx file names to List_Ignored for this specific OwnerClass's ObjectPath
                        if Show_Ignored != "F":
                            print(f"Adding {scs_variable_name} to List_Ignored for {owner_class_path}")
                        List_Ignored.append(scs_variable_name + ".json")
                        List_Ignored.append(scs_variable_name + ".pskx")

                        # Process the full object path using SCSVariableName info
                        valid_paths_count, valid_pskx_count, invalid_paths_count = process_and_check_file_path(file_path, ".json", True, processed_file_paths, valid_paths_count, valid_pskx_count, invalid_paths_count, location_data, cube)

                        nested_pskx_paths, nested_json_paths, unknown_types_nested, valid_paths_count, valid_pskx_count, invalid_paths_count = read_json_file(
                            file_path, known_paths, processed_file_paths, valid_paths_count, valid_pskx_count, invalid_paths_count, location_data, txt_location_data, cube
                        )
                        pskx_paths.extend(nested_pskx_paths)
                        json_paths.extend(nested_json_paths)
                        unknown_types += unknown_types_nested

                        # Remove both .json and .pskx versions of SCSVariableName from List_Ignored after processing
                        if Show_Ignored != "F":
                            print(f"Removing {scs_variable_name} (both .json and .pskx) from List_Ignored")
                        List_Ignored.remove(scs_variable_name + ".json")
                        List_Ignored.remove(scs_variable_name + ".pskx")

            # Process other properties listed in List_Properties_Names
            for prop_name in List_Properties_Names:
                if prop_name in record:  # Only process properties that are in List_Properties_Names
                    prop_data = record[prop_name]
                    if isinstance(prop_data, dict) and "ObjectPath" in prop_data:
                        object_path = prop_data["ObjectPath"].strip('"')
                        if object_path:
                            file_path = combine_paths(base_path_Json, object_path, ".json", True)
                            valid_paths_count, valid_pskx_count, invalid_paths_count = process_and_check_file_path(file_path, ".json", True, processed_file_paths, valid_paths_count, valid_pskx_count, invalid_paths_count, location_data, cube)

                            # Recursively process this file path, now checking against ignored names
                            nested_pskx_paths, nested_json_paths, unknown_types_nested, valid_paths_count, valid_pskx_count, invalid_paths_count = read_json_file(
                                file_path, known_paths, processed_file_paths, valid_paths_count, valid_pskx_count, invalid_paths_count, location_data, txt_location_data, cube
                            )
                            pskx_paths.extend(nested_pskx_paths)
                            json_paths.extend(nested_json_paths)
                            unknown_types += unknown_types_nested

    # Handle Meshes[4] and similar array properties
    for prop_name in properties:
        # Extract base property name (e.g., "Meshes[4]" -> "Meshes")
        base_prop_name = prop_name.split("[")[0]

        if base_prop_name in List_Properties_Names:
            prop_data = properties[prop_name]

            # Print the property if Show_Properties is "T"
            if Show_Properties == "T":
                print(f"Found property: {prop_name}")

            # Handle list of dictionaries with ObjectPath
            if isinstance(prop_data, list):
                for entry in prop_data:
                    if isinstance(entry, dict) and "ObjectPath" in entry:
                        object_path = entry["ObjectPath"].strip('"')
                        if object_path:
                            file_path = combine_paths(
                                base_path_Pskx if type_value in List_Pskx else base_path_Json,
                                object_path,
                                ".pskx" if type_value in List_Pskx else ".json",
                                type_value in List_Json
                            )
                            # Check if the file path matches any SCSVariableName in List_Ignored
                            if object_path.split("\\")[-1] not in List_Ignored or Show_Ignored == "T":
                                if type_value in List_Pskx:
                                    pskx_paths.append(file_path)
                                else:
                                    json_paths.append(file_path)

                                valid_paths_count, valid_pskx_count, invalid_paths_count = process_and_check_file_path(
                                    file_path,
                                    ".pskx" if type_value in List_Pskx else ".json",
                                    type_value in List_Json,
                                    processed_file_paths,
                                    valid_paths_count,
                                    valid_pskx_count,
                                    invalid_paths_count,
                                    location_data,
                                    cube
                                )

            # Handle single dictionary with ObjectPath
            elif isinstance(prop_data, dict) and "ObjectPath" in prop_data:
                object_path = prop_data["ObjectPath"].strip('"')
                if object_path:
                    file_path = combine_paths(
                        base_path_Pskx if type_value in List_Pskx else base_path_Json,
                        object_path,
                        ".pskx" if type_value in List_Pskx else ".json",
                        type_value in List_Json
                    )
                    # Check if the file path matches any SCSVariableName in List_Ignored
                    if object_path.split("\\")[-1] not in List_Ignored or Show_Ignored == "T":
                        if type_value in List_Pskx:
                            pskx_paths.append(file_path)
                        else:
                            json_paths.append(file_path)

                    valid_paths_count, valid_pskx_count, invalid_paths_count = process_and_check_file_path(
                        file_path,
                        ".pskx" if type_value in List_Pskx else ".json",
                        type_value in List_Json,
                        processed_file_paths,
                        valid_paths_count,
                        valid_pskx_count,
                        invalid_paths_count,
                        location_data,
                        cube
                    )

                    # Recursively process nested JSON files
                    if type_value in List_Json:
                        nested_pskx_paths, nested_json_paths, unknown_types_nested, valid_paths_count, valid_pskx_count, invalid_paths_count = read_json_file(
                            file_path, known_paths, processed_file_paths, valid_paths_count, valid_pskx_count, invalid_paths_count, location_data, txt_location_data, cube
                        )
                        pskx_paths.extend(nested_pskx_paths)
                        json_paths.extend(nested_json_paths)
                        unknown_types += unknown_types_nested

    return pskx_paths, json_paths, unknown_types, valid_paths_count, valid_pskx_count, invalid_paths_count 

# Prepares and adjusts locational data based on parent and property transformations.
def prepare_location_data(parent_location, properties, txt_location_data=None):
    # Create a deep copy of the parent location to ensure unique data for each file
    location_data = copy.deepcopy(parent_location) if parent_location else {
        "Location": {"X": 0.0, "Y": 0.0, "Z": 0.0},
        "Rotation": {"Roll": 0.0, "Pitch": 0.0, "Yaw": 0.0},
        "Scale": {"X": 1.0, "Y": 1.0, "Z": 1.0}
    }

    # Process RelativeLocation, RelativeRotation, and RelativeScale3D
    if "RelativeLocation" in properties:
        relative_location = process_transform(properties["RelativeLocation"], "location")
        location_data["Location"]["X"] += relative_location.get("X", 0.0)
        location_data["Location"]["Y"] += relative_location.get("Y", 0.0)
        location_data["Location"]["Z"] += relative_location.get("Z", 0.0)

    if "RelativeRotation" in properties:
        relative_rotation = process_transform(properties["RelativeRotation"], "rotation")
        location_data["Rotation"]["Roll"] += relative_rotation.get("Roll", 0.0)
        location_data["Rotation"]["Pitch"] += relative_rotation.get("Pitch", 0.0)
        location_data["Rotation"]["Yaw"] += relative_rotation.get("Yaw", 0.0)

    if "RelativeScale3D" in properties:
        relative_scale = process_transform(properties["RelativeScale3D"], "scale")
        location_data["Scale"]["X"] *= relative_scale.get("X", 1.0)
        location_data["Scale"]["Y"] *= relative_scale.get("Y", 1.0)
        location_data["Scale"]["Z"] *= relative_scale.get("Z", 1.0)

    # Incorporate locational data from the TXT file if provided
    if txt_location_data:
        location_data["Location"]["X"] += txt_location_data.get("Location", {}).get("X", 0.0)
        location_data["Location"]["Y"] += txt_location_data.get("Location", {}).get("Y", 0.0)
        location_data["Location"]["Z"] += txt_location_data.get("Location", {}).get("Z", 0.0)

        location_data["Rotation"]["Roll"] += txt_location_data.get("Rotation", {}).get("Roll", 0.0)
        location_data["Rotation"]["Pitch"] += txt_location_data.get("Rotation", {}).get("Pitch", 0.0)
        location_data["Rotation"]["Yaw"] += txt_location_data.get("Rotation", {}).get("Yaw", 0.0)

        location_data["Scale"]["X"] *= txt_location_data.get("Scale", {}).get("X", 1.0)
        location_data["Scale"]["Y"] *= txt_location_data.get("Scale", {}).get("Y", 1.0)
        location_data["Scale"]["Z"] *= txt_location_data.get("Scale", {}).get("Z", 1.0)

    return location_data


# Combines base and object paths to form a complete file path, ensuring correct format.
def combine_paths(base_path, obj_path, extension, is_json):
    # Ensure the object path uses backslashes for consistency
    obj_path = obj_path.replace("/", "\\")  # Ensure backslashes in obj_path

    # Ensure base_path is using backslashes
    base_path = base_path.replace("/", "\\")

    # Remove the "Game\\Assets" part from the base_path if it exists
    if base_path.endswith("\\Game\\Assets"):
        base_path = base_path[:base_path.rfind("\\Game") + len("\\Game")]

    # Remove the leading "\Game" from object path if it starts with it
    if obj_path.startswith("\\Game\\"):
        obj_path = obj_path[len("\\Game\\"):]

    # Ensure the file has the correct extension (either .json or .pskx)
    obj_path = obj_path.rsplit(".", 1)[0] + extension

    # Combine base_path with the modified object path
    full_path = base_path + "\\" + obj_path  # Make sure to use "\\" to join paths

    # Return the full path
    return full_path

# Function to select the Scene Collection
def select_scene_collection():
    if Collection_Auto_Select == "T":
        # Deselect all collections
        bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection
        print("Scene Collection has been selected.")

# Main execution function that orchestrates reading, processing, and importing data.
def main():

    select_scene_collection()

    total_unknown_types = 0
    valid_paths_count = 0
    valid_pskx_count = 0
    invalid_paths_count = 0
    processed_file_paths = {}
    name_count = {}  # Dictionary to keep track of name counts

    # Read the locational data from the TXT file
    missing_data, _ = read_tandem_txt(txt_file_path)  # Ignore locational_data_list

    if not missing_data:
        print("No missing data found.")
        return

    # Create cubes for each missing entry in the txt file
    cubes = []
    for index, data in enumerate(missing_data):
        name = data['name']
        if name not in name_count:
            name_count[name] = 0
        cube = create_cube(name, data['locational_data'], name_count)
        cubes.append(cube)

    # Process the missing data to get valid paths
    valid_pskx_paths, valid_json_paths = process_json(missing_data, cubes)

    known_paths = set()
    all_pskx_paths = []
    all_json_paths = []

    # Process each valid JSON path
    for path, cube in valid_json_paths:
        pskx_paths, json_paths, unknown_types, valid_paths_count, valid_pskx_count, invalid_paths_count = read_json_file(
            path, known_paths, processed_file_paths, valid_paths_count, valid_pskx_count, invalid_paths_count, cube=cube
        )
        all_pskx_paths.extend(pskx_paths)
        all_json_paths.extend(json_paths)

        total_unknown_types += unknown_types

    # Import PSKX files and associate them with cubes
    for path, cube in valid_pskx_paths:
        import_pskx_with_blender(path, None, cube)  # Pass None for locational_data

    # Hide all cubes
    for cube in cubes:
        if cube is not None:
            cube.hide_viewport = True
            cube.hide_render = True

    # New functionality: Remove parent cubes and clear parent while keeping transforms
    if Remove_cube_parent == "T":
        # Get the collection
        collection = bpy.data.collections.get(Collection_name)
        if collection:
            # Clear parent for all objects in the collection
            for obj in collection.objects:
                if obj.parent:
                    bpy.ops.object.select_all(action='DESELECT')
                    obj.select_set(True)
                    bpy.context.view_layer.objects.active = obj
                    bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')

            # Delete all cubes
            for cube in cubes:
                if cube is not None:
                    bpy.data.objects.remove(cube, do_unlink=True)

    print(f"Paths found: {len(all_pskx_paths + all_json_paths)}")
    print(f"Valid paths: {valid_paths_count}")
    if Show_Unknown_Type == "T":
        print(f"Total Unknown types found: {total_unknown_types}")
    print(f"Valid pskx file found: {valid_pskx_count}")
    print(f"Invalid paths count: {invalid_paths_count}")

# Run the script
main()